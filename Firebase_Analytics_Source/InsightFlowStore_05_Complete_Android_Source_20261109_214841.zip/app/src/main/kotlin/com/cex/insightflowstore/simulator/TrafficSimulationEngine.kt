package com.cex.insightflowstore.simulator

import com.cex.insightflowstore.analytics.AnalyticsTracker
import com.cex.insightflowstore.data.SampleProducts
import com.cex.insightflowstore.model.CartItem
import com.cex.insightflowstore.model.Order
import com.cex.insightflowstore.model.Product
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import java.util.UUID
import kotlin.random.Random

data class SimulationState(
    val isRunning: Boolean = false,
    val currentScenario: AnomalyScenario? = null,
    val completedSessions: Int = 0,
    val totalSessions: Int = 0,
    val statusMessage: String = "Idle"
)

class TrafficSimulationEngine(
    private val tracker: AnalyticsTracker,
    private val scope: CoroutineScope
) {
    private val _state = MutableStateFlow(SimulationState())
    val state: StateFlow<SimulationState> = _state.asStateFlow()

    private var activeJob: Job? = null

    fun startSimulation(scenario: AnomalyScenario, sessionCount: Int = 20, delayMsBetweenEvents: Long = 100L) {
        if (_state.value.isRunning) return

        activeJob = scope.launch(Dispatchers.Default) {
            _state.value = SimulationState(
                isRunning = true,
                currentScenario = scenario,
                completedSessions = 0,
                totalSessions = sessionCount,
                statusMessage = "Starting ${scenario.title} ($sessionCount sessions)..."
            )

            try {
                for (i in 1..sessionCount) {
                    _state.value = _state.value.copy(
                        completedSessions = i,
                        statusMessage = "Simulating session $i / $sessionCount (${scenario.code})"
                    )

                    simulateSingleSession(scenario, delayMsBetweenEvents)
                    delay(delayMsBetweenEvents)
                }

                _state.value = _state.value.copy(
                    isRunning = false,
                    statusMessage = "Completed $sessionCount sessions for ${scenario.title}."
                )
            } catch (e: CancellationException) {
                _state.value = _state.value.copy(
                    isRunning = false,
                    statusMessage = "Simulation cancelled."
                )
            } catch (e: Exception) {
                _state.value = _state.value.copy(
                    isRunning = false,
                    statusMessage = "Error during simulation: ${e.message}"
                )
            }
        }
    }

    fun stopSimulation() {
        activeJob?.cancel()
        _state.value = _state.value.copy(
            isRunning = false,
            statusMessage = "Simulation stopped by user."
        )
    }

    private suspend fun simulateSingleSession(scenario: AnomalyScenario, stepDelay: Long) {
        val products = SampleProducts.items
        val categories = products.map { it.category }.distinct()

        // Step 1: Browse category / view list
        val selectedCategory = categories.random()
        val categoryProducts = products.filter { it.category == selectedCategory }
        tracker.logViewItemList(selectedCategory, categoryProducts)
        delay(stepDelay)

        // Adjust candidate products based on AOV_DECLINE scenario
        val pool = when (scenario) {
            AnomalyScenario.AOV_DECLINE -> products.filter { it.price < 60.0 }.ifEmpty { products }
            else -> products
        }

        // Step 2: View 1 to 3 items
        val viewCount = when (scenario) {
            AnomalyScenario.TRAFFIC_DECLINE -> 1
            else -> Random.nextInt(1, 4)
        }
        val viewedItems = pool.shuffled().take(viewCount)
        for (item in viewedItems) {
            tracker.logViewItem(item)
            delay(stepDelay)
        }

        // Step 3: Add to cart probability
        val addToCartProb = when (scenario) {
            AnomalyScenario.NORMAL -> 0.40
            AnomalyScenario.TRAFFIC_DECLINE -> 0.35
            AnomalyScenario.CONVERSION_REGRESSION -> 0.45 // users still add to cart!
            AnomalyScenario.AOV_DECLINE -> 0.60
            AnomalyScenario.CHECKOUT_REGRESSION -> 0.50
            AnomalyScenario.GLOBAL_ANOMALY -> 0.15
        }

        if (Random.nextDouble() > addToCartProb) {
            // User bounced after browsing
            return
        }

        val cartProducts = viewedItems.shuffled().take(Random.nextInt(1, viewedItems.size + 1))
        val cartItems = cartProducts.map {
            CartItem(product = it, quantity = if (scenario == AnomalyScenario.AOV_DECLINE) 1 else Random.nextInt(1, 3))
        }

        for (item in cartItems) {
            tracker.logAddToCart(item.product, item.quantity)
            delay(stepDelay)
        }

        val cartSubtotal = cartItems.sumOf { it.subtotal }
        tracker.logViewCart(cartItems, cartSubtotal)
        delay(stepDelay)

        // Step 4: Begin Checkout probability
        val beginCheckoutProb = when (scenario) {
            AnomalyScenario.NORMAL -> 0.60
            AnomalyScenario.TRAFFIC_DECLINE -> 0.50
            AnomalyScenario.CONVERSION_REGRESSION -> 0.10 // Heavy cart abandonment!
            AnomalyScenario.AOV_DECLINE -> 0.70
            AnomalyScenario.CHECKOUT_REGRESSION -> 0.80 // Enters checkout funnel!
            AnomalyScenario.GLOBAL_ANOMALY -> 0.10
        }

        if (Random.nextDouble() > beginCheckoutProb) {
            // Cart abandoned
            return
        }

        tracker.logBeginCheckout(cartItems, cartSubtotal)
        delay(stepDelay)

        tracker.logAddShippingInfo(cartItems, cartSubtotal)
        delay(stepDelay)

        val paymentType = listOf("Credit Card", "Google Pay", "PayPal").random()
        tracker.logAddPaymentInfo(cartItems, cartSubtotal, paymentType)
        delay(stepDelay)

        // Step 5: Final Purchase probability
        val purchaseProb = when (scenario) {
            AnomalyScenario.NORMAL -> 0.85
            AnomalyScenario.TRAFFIC_DECLINE -> 0.80
            AnomalyScenario.CONVERSION_REGRESSION -> 0.50
            AnomalyScenario.AOV_DECLINE -> 0.90
            AnomalyScenario.CHECKOUT_REGRESSION -> 0.05 // Severe checkout crash / payment failure!
            AnomalyScenario.GLOBAL_ANOMALY -> 0.10
        }

        if (Random.nextDouble() > purchaseProb) {
            // Checkout failed / aborted
            return
        }

        val discount = if (scenario == AnomalyScenario.AOV_DECLINE) cartSubtotal * 0.50 else 0.0
        val finalTotal = (cartSubtotal - discount).coerceAtLeast(0.0)

        val order = Order(
            orderId = "SIM-" + UUID.randomUUID().toString().take(8).uppercase(),
            items = cartItems,
            totalAmount = finalTotal,
            discountAmount = discount,
            timestamp = System.currentTimeMillis()
        )
        tracker.logPurchase(order)
    }
}
