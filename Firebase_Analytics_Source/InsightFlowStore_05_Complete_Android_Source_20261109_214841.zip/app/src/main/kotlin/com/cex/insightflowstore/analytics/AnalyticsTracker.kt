package com.cex.insightflowstore.analytics

import android.content.Context
import android.os.Bundle
import android.util.Log
import com.cex.insightflowstore.model.CartItem
import com.cex.insightflowstore.model.Order
import com.cex.insightflowstore.model.Product
import com.google.firebase.analytics.FirebaseAnalytics
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID

data class AnalyticsLogEntry(
    val id: String = UUID.randomUUID().toString(),
    val eventName: String,
    val details: String,
    val timestamp: Long = System.currentTimeMillis()
) {
    val formattedTime: String
        get() = SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(Date(timestamp))
}

interface AnalyticsTracker {
    val eventLogs: StateFlow<List<AnalyticsLogEntry>>
    fun clearLogs()
    fun logViewItemList(category: String, items: List<Product>)
    fun logViewItem(product: Product)
    fun logAddToCart(product: Product, quantity: Int = 1)
    fun logRemoveFromCart(product: Product, quantity: Int = 1)
    fun logViewCart(items: List<CartItem>, total: Double)
    fun logBeginCheckout(items: List<CartItem>, total: Double)
    fun logAddShippingInfo(items: List<CartItem>, total: Double)
    fun logAddPaymentInfo(items: List<CartItem>, total: Double, paymentType: String = "Credit Card")
    fun logPurchase(order: Order)
}

class AppAnalyticsTracker(private val context: Context) : AnalyticsTracker {

    private val firebase: FirebaseAnalytics? by lazy {
        try {
            FirebaseAnalytics.getInstance(context)
        } catch (e: Exception) {
            Log.w(TAG, "Firebase Analytics not available (google-services.json may not be configured yet): ${e.message}")
            null
        }
    }

    private val _eventLogs = MutableStateFlow<List<AnalyticsLogEntry>>(emptyList())
    override val eventLogs: StateFlow<List<AnalyticsLogEntry>> = _eventLogs.asStateFlow()

    override fun clearLogs() {
        _eventLogs.value = emptyList()
    }

    private fun recordEvent(name: String, details: String, params: Bundle? = null) {
        Log.i(TAG, "[$name] $details")
        firebase?.logEvent(name, params)

        val entry = AnalyticsLogEntry(eventName = name, details = details)
        val current = _eventLogs.value.toMutableList()
        current.add(0, entry)
        if (current.size > 200) {
            _eventLogs.value = current.take(200)
        } else {
            _eventLogs.value = current
        }
    }

    override fun logViewItemList(category: String, items: List<Product>) {
        val params = Bundle().apply {
            putString(EcommerceEvents.PARAM_ITEM_CATEGORY, category)
        }
        recordEvent(
            EcommerceEvents.EVENT_VIEW_ITEM_LIST,
            "Browsed category: $category (${items.size} items)",
            params
        )
    }

    override fun logViewItem(product: Product) {
        val params = Bundle().apply {
            putString(EcommerceEvents.PARAM_CURRENCY, EcommerceEvents.DEFAULT_CURRENCY)
            putDouble(EcommerceEvents.PARAM_VALUE, product.price)
            putParcelableArray(
                EcommerceEvents.PARAM_ITEMS,
                arrayOf(EcommerceEvents.productToBundle(product))
            )
        }
        recordEvent(
            EcommerceEvents.EVENT_VIEW_ITEM,
            "Viewed '${product.name}' ($${product.price})",
            params
        )
    }

    override fun logAddToCart(product: Product, quantity: Int) {
        val total = product.price * quantity
        val params = Bundle().apply {
            putString(EcommerceEvents.PARAM_CURRENCY, EcommerceEvents.DEFAULT_CURRENCY)
            putDouble(EcommerceEvents.PARAM_VALUE, total)
            putParcelableArray(
                EcommerceEvents.PARAM_ITEMS,
                arrayOf(EcommerceEvents.productToBundle(product, quantity))
            )
        }
        recordEvent(
            EcommerceEvents.EVENT_ADD_TO_CART,
            "Added $quantity x '${product.name}' ($${total})",
            params
        )
    }

    override fun logRemoveFromCart(product: Product, quantity: Int) {
        val total = product.price * quantity
        val params = Bundle().apply {
            putString(EcommerceEvents.PARAM_CURRENCY, EcommerceEvents.DEFAULT_CURRENCY)
            putDouble(EcommerceEvents.PARAM_VALUE, total)
            putParcelableArray(
                EcommerceEvents.PARAM_ITEMS,
                arrayOf(EcommerceEvents.productToBundle(product, quantity))
            )
        }
        recordEvent(
            EcommerceEvents.EVENT_REMOVE_FROM_CART,
            "Removed $quantity x '${product.name}' ($${total})",
            params
        )
    }

    override fun logViewCart(items: List<CartItem>, total: Double) {
        val bundles = items.map { EcommerceEvents.cartItemToBundle(it) }.toTypedArray()
        val params = Bundle().apply {
            putString(EcommerceEvents.PARAM_CURRENCY, EcommerceEvents.DEFAULT_CURRENCY)
            putDouble(EcommerceEvents.PARAM_VALUE, total)
            putParcelableArray(EcommerceEvents.PARAM_ITEMS, bundles)
        }
        recordEvent(
            EcommerceEvents.EVENT_VIEW_CART,
            "Viewed cart: ${items.size} unique items, Total=$${String.format(Locale.US, "%.2f", total)}",
            params
        )
    }

    override fun logBeginCheckout(items: List<CartItem>, total: Double) {
        val bundles = items.map { EcommerceEvents.cartItemToBundle(it) }.toTypedArray()
        val params = Bundle().apply {
            putString(EcommerceEvents.PARAM_CURRENCY, EcommerceEvents.DEFAULT_CURRENCY)
            putDouble(EcommerceEvents.PARAM_VALUE, total)
            putParcelableArray(EcommerceEvents.PARAM_ITEMS, bundles)
        }
        recordEvent(
            EcommerceEvents.EVENT_BEGIN_CHECKOUT,
            "Started checkout: ${items.size} items, Total=$${String.format(Locale.US, "%.2f", total)}",
            params
        )
    }

    override fun logAddShippingInfo(items: List<CartItem>, total: Double) {
        val bundles = items.map { EcommerceEvents.cartItemToBundle(it) }.toTypedArray()
        val params = Bundle().apply {
            putString(EcommerceEvents.PARAM_CURRENCY, EcommerceEvents.DEFAULT_CURRENCY)
            putDouble(EcommerceEvents.PARAM_VALUE, total)
            putParcelableArray(EcommerceEvents.PARAM_ITEMS, bundles)
        }
        recordEvent(
            EcommerceEvents.EVENT_ADD_SHIPPING_INFO,
            "Added shipping details, Total=$${String.format(Locale.US, "%.2f", total)}",
            params
        )
    }

    override fun logAddPaymentInfo(items: List<CartItem>, total: Double, paymentType: String) {
        val bundles = items.map { EcommerceEvents.cartItemToBundle(it) }.toTypedArray()
        val params = Bundle().apply {
            putString(EcommerceEvents.PARAM_CURRENCY, EcommerceEvents.DEFAULT_CURRENCY)
            putDouble(EcommerceEvents.PARAM_VALUE, total)
            putString(EcommerceEvents.PARAM_PAYMENT_TYPE, paymentType)
            putParcelableArray(EcommerceEvents.PARAM_ITEMS, bundles)
        }
        recordEvent(
            EcommerceEvents.EVENT_ADD_PAYMENT_INFO,
            "Added payment info ($paymentType), Total=$${String.format(Locale.US, "%.2f", total)}",
            params
        )
    }

    override fun logPurchase(order: Order) {
        val bundles = order.items.map { EcommerceEvents.cartItemToBundle(it) }.toTypedArray()
        val params = Bundle().apply {
            putString(EcommerceEvents.PARAM_TRANSACTION_ID, order.orderId)
            putString(EcommerceEvents.PARAM_CURRENCY, EcommerceEvents.DEFAULT_CURRENCY)
            putDouble(EcommerceEvents.PARAM_VALUE, order.totalAmount)
            putParcelableArray(EcommerceEvents.PARAM_ITEMS, bundles)
        }
        recordEvent(
            EcommerceEvents.EVENT_PURCHASE,
            "Completed Purchase #${order.orderId}: Total=$${String.format(Locale.US, "%.2f", order.totalAmount)}",
            params
        )
    }

    companion object {
        private const val TAG = "GA4_ANALYTICS"
    }
}
